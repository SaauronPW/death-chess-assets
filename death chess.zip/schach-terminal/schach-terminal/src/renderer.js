'use strict';

// ════════════════════════════════════════════════
// TERMINAL RENDERER
// Farbiges Schachbrett im Terminal
// ════════════════════════════════════════════════

const chalk = require('chalk');

// Figurensymbole
const PIECES = {
  wK: '♔', wQ: '♕', wR: '♖', wB: '♗', wN: '♘', wP: '♙',
  bK: '♚', bQ: '♛', bR: '♜', bB: '♝', bN: '♞', bP: '♟',
};

// Fallback für Terminals ohne Unicode
const PIECES_ASCII = {
  wK: 'K', wQ: 'Q', wR: 'R', wB: 'B', wN: 'N', wP: 'P',
  bK: 'k', bQ: 'q', bR: 'r', bB: 'b', bN: 'n', bP: 'p',
};

// Farben
const C = {
  lightSq:    chalk.bgHex('#d4a574'),
  darkSq:     chalk.bgHex('#8b4513'),
  lightSqHl:  chalk.bgHex('#f0c040'),   // selected
  darkSqHl:   chalk.bgHex('#c89010'),
  lightSqMv:  chalk.bgHex('#90c060'),   // valid move
  darkSqMv:   chalk.bgHex('#5a9030'),
  lightSqCap: chalk.bgHex('#e06040'),   // capture
  darkSqCap:  chalk.bgHex('#a03020'),
  lightSqLst: chalk.bgHex('#88a0d0'),   // last move
  darkSqLst:  chalk.bgHex('#4060a0'),
  whitePiece: chalk.bold.whiteBright,
  blackPiece: chalk.bold.hex('#111111'),
  coord:      chalk.hex('#8a6030').bold,
  border:     chalk.hex('#5a3010'),
  title:      chalk.hex('#e8c060').bold,
  info:       chalk.hex('#c8a040'),
  dim:        chalk.hex('#6a5030'),
  check:      chalk.bgRed.white.bold,
  win:        chalk.hex('#50e050').bold,
  loss:       chalk.hex('#e05050').bold,
  draw:       chalk.hex('#9090e0').bold,
  prompt:     chalk.hex('#e8c060').bold,
  good:       chalk.hex('#60d060'),
  bad:        chalk.hex('#e06060'),
  move:       chalk.hex('#c0c0e0'),
  sep:        chalk.hex('#3a2010'),
  white_lbl:  chalk.hex('#f0e8d0').bold,
  black_lbl:  chalk.hex('#888888').bold,
  score_pos:  chalk.hex('#60d060'),
  score_neg:  chalk.hex('#e06060'),
};

function renderBoard(S, highlights = {}, opts = {}) {
  const { useUnicode = true, flipped = false } = opts;
  const glyphs = useUnicode ? PIECES : PIECES_ASCII;
  const { selected, moves = [], captures = [], lastFrom, lastTo } = highlights;

  const moveSet    = new Set(moves.map(m => m.r + '_' + m.f));
  const captureSet = new Set(captures.map(m => m.r + '_' + m.f));
  const lastSet    = new Set([
    lastFrom ? `${lastFrom.r}_${lastFrom.f}` : null,
    lastTo   ? `${lastTo.r}_${lastTo.f}` : null,
  ].filter(Boolean));

  const lines = [];

  // ── Top border ──────────────────────────
  const fileLabels = '  ' + ' abcdefgh'.split('').map((c, i) => i === 0 ? '  ' : ` ${c} `).join('');
  lines.push(C.coord(flipped ? '  h  g  f  e  d  c  b  a' : '  a  b  c  d  e  f  g  h'));

  const ranks = flipped ? [0,1,2,3,4,5,6,7] : [7,6,5,4,3,2,1,0];
  const files = flipped ? [7,6,5,4,3,2,1,0] : [0,1,2,3,4,5,6,7];

  for (const r of ranks) {
    let row = C.coord(` ${8 - r} `);
    for (const f of files) {
      const isLight = (r + f) % 2 !== 0;
      const key = `${r}_${f}`;
      const piece = S.board[r][f];
      const g = piece ? (glyphs[piece] || '?') : ' ';
      const isWhite = piece?.[0] === 'w';

      // Determine square background
      let bgFn;
      if (selected && selected.r === r && selected.f === f)
        bgFn = isLight ? C.lightSqHl : C.darkSqHl;
      else if (captureSet.has(key))
        bgFn = isLight ? C.lightSqCap : C.darkSqCap;
      else if (moveSet.has(key))
        bgFn = isLight ? C.lightSqMv  : C.darkSqMv;
      else if (lastSet.has(key))
        bgFn = isLight ? C.lightSqLst : C.darkSqLst;
      else
        bgFn = isLight ? C.lightSq    : C.darkSq;

      // Dot indicator for move targets (no piece on that square)
      let display;
      if (!piece && moveSet.has(key)) {
        display = bgFn(' · ');
      } else if (piece) {
        const pieceStyled = isWhite
          ? C.whitePiece(` ${g} `)
          : C.blackPiece(` ${g} `);
        display = bgFn(pieceStyled);
      } else {
        display = bgFn('   ');
      }
      row += display;
    }
    row += C.coord(` ${8 - r}`);
    lines.push(row);
  }
  lines.push(C.coord(flipped ? '  h  g  f  e  d  c  b  a' : '  a  b  c  d  e  f  g  h'));
  return lines.join('\n');
}

function renderMoveHistory(moves, cols = 2) {
  if (!moves.length) return C.dim('  (keine Züge)');
  const pairs = [];
  for (let i = 0; i < moves.length; i += 2)
    pairs.push({ n: Math.floor(i / 2) + 1, w: moves[i], b: moves[i + 1] || '' });
  const recent = pairs.slice(-6);
  return recent.map(p =>
    C.dim(`${String(p.n).padStart(2, ' ')}.`) + ' ' +
    C.move(p.w.padEnd(8)) +
    (p.b ? C.dim(p.b) : '')
  ).join('\n');
}

function renderCaptured(pieces) {
  const GLYPH = { P: '♟', N: '♞', B: '♝', R: '♜', Q: '♛', K: '♚' };
  const PV = { Q: 9, R: 5, B: 3, N: 3, P: 1, K: 0 };
  const grouped = {};
  for (const p of pieces) {
    const t = p[1]; grouped[t] = (grouped[t] || 0) + 1;
  }
  const sorted = Object.entries(grouped).sort((a, b) => PV[b[0]] - PV[a[0]]);
  return sorted.map(([t, n]) => (GLYPH[t] || t).repeat(n)).join(' ');
}

function clearScreen() {
  process.stdout.write('\x1B[2J\x1B[0f');
}

function renderStatus(S, moveHistory, capturedByWhite, capturedByBlack, lastMsg, aiLevel) {
  const { isInCheck, sqToStr } = require('./engine');
  const inCheckNow = isInCheck(S, S.turn);

  const lines = [];

  // ── Header ──────────────────────────────
  lines.push('');
  lines.push(C.title('  ╔══════════════════════════════╗'));
  lines.push(C.title('  ║         S C H A C H          ║'));
  lines.push(C.title('  ╚══════════════════════════════╝'));
  lines.push('');

  // ── Captured by white (black pieces captured) ──
  const captB = renderCaptured(capturedByWhite);
  lines.push(C.white_lbl('  ✦ Weiß:') + (captB ? C.good('  ' + captB) : C.dim('  —')));

  return lines.join('\n');
}

function box(title, content, width = 32) {
  const inner = width - 2;
  const top    = C.sep('┌' + '─'.repeat(inner) + '┐');
  const bot    = C.sep('└' + '─'.repeat(inner) + '┘');
  const ttl    = C.sep('│') + C.info((' ' + title).padEnd(inner)) + C.sep('│');
  const lines  = [top, ttl, C.sep('│' + '─'.repeat(inner) + '│')];
  for (const line of content) {
    const clean = line.replace(/\x1B\[[0-9;]*m/g, '');
    const padding = Math.max(0, inner - 1 - clean.length);
    lines.push(C.sep('│') + ' ' + line + ' '.repeat(padding) + C.sep('│'));
  }
  lines.push(bot);
  return lines.join('\n');
}

module.exports = { renderBoard, renderMoveHistory, renderCaptured, clearScreen, renderStatus, C, PIECES, box };
