#!/usr/bin/env node
'use strict';

// ════════════════════════════════════════════════
// SCHACH TERMINAL – Hauptspiel
// Vollständige Schach-Implementierung im Terminal
// ════════════════════════════════════════════════

const readline = require('readline');
const {
  makeState, applyMove, getLegalMoves, getAllLegalMoves,
  hasAnyLegal, isInCheck, parseAlg, sqToStr, toAlg, moveToSAN, findBestMove,
} = require('./engine');
const { renderBoard, renderMoveHistory, renderCaptured, clearScreen, C } = require('./renderer');

// ── Readline-Interface ───────────────────────
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: true,
});

function ask(prompt) {
  return new Promise(resolve => rl.question(prompt, resolve));
}

// ── Spielstand ───────────────────────────────
let S           = null;
let gameActive  = false;
let aiLevel     = 3;
let moveHistory = [];         // SAN strings
let capturedW   = [];         // Figuren die Weiß geschlagen hat
let capturedB   = [];         // Figuren die Schwarz geschlagen hat
let lastFrom    = null;
let lastTo      = null;
let highlights  = {};
let flipped     = false;
let selected    = null;
let selectedMoves = [];
let promoMode   = false;

// ── Render ────────────────────────────────────
function draw(message = '', msgType = 'info') {
  clearScreen();

  const inCheck = isInCheck(S, S.turn);
  const isWhite = S.turn === 'w';

  // ── Titel ────────────────────────────────
  console.log('');
  console.log(C.title('  ╔══════════════════════════════╗'));
  console.log(C.title('  ║       ♔  S C H A C H  ♛      ║'));
  console.log(C.title('  ╚══════════════════════════════╝'));
  console.log('');

  // ── Geschlagene Figuren (Schwarz) ────────
  const captB_str = renderCaptured(capturedW);
  console.log(C.black_lbl('  ▲ Schwarz (KI)') +
    (captB_str ? C.bad('   ' + captB_str) : C.dim('   —')));

  // ── Brett ────────────────────────────────
  const hl = {
    selected: selected ? { r: selected.r, f: selected.f } : null,
    moves: selected ? selectedMoves.filter(m => !S.board[m.r][m.f]).map(m => ({r:m.r,f:m.f})) : [],
    captures: selected ? selectedMoves.filter(m => !!S.board[m.r][m.f] || m.ep).map(m => ({r:m.r,f:m.f})) : [],
    lastFrom, lastTo,
  };
  console.log(renderBoard(S, hl, { flipped }));

  // ── Geschlagene Figuren (Weiß) ───────────
  const captW_str = renderCaptured(capturedB);
  console.log(C.white_lbl('  ▼ Weiß (Du)') +
    (captW_str ? C.good('     ' + captW_str) : C.dim('     —')));

  console.log('');

  // ── Status Panel ─────────────────────────
  const turnLine = isWhite
    ? C.white_lbl('  AM ZUG: ') + C.good('Weiß ♔')
    : C.white_lbl('  AM ZUG: ') + C.bad('Schwarz ♛ (KI)');
  console.log(turnLine);

  if (inCheck) {
    console.log(C.check('  ⚠  SCHACH!  ⚠'));
  }

  if (selected) {
    console.log(C.info('  GEWÄHLT: ') + C.prompt(sqToStr(selected.r, selected.f)) +
      C.dim('  (' + selectedMoves.length + ' Züge möglich)'));
  }

  // ── Zugliste ─────────────────────────────
  if (moveHistory.length) {
    console.log('');
    console.log(C.dim('  ─── Letzte Züge ───────────────'));
    const recent = moveHistory.slice(-8);
    const pairs = [];
    for (let i = 0; i < recent.length; i += 2)
      pairs.push({
        n: Math.floor((moveHistory.length - recent.length + i) / 2) + 1,
        w: recent[i], b: recent[i + 1] || '',
      });
    for (const p of pairs)
      console.log(
        C.dim(`  ${String(p.n).padStart(2)}. `) +
        C.move(p.w.padEnd(9)) +
        (p.b ? C.dim(p.b) : '')
      );
  }

  // ── KI-Info ──────────────────────────────
  console.log('');
  console.log(C.dim(`  ─── Info ──────────────────────`));
  console.log(C.dim(`  KI-Stärke: `) + C.info('Stufe ' + aiLevel + ' / 5'));
  console.log(C.dim(`  Brett:    `) + C.info(flipped ? 'umgekehrt' : 'normal'));
  console.log(C.dim(`  Vollzüge: `) + C.info(S.fullmove));

  // ── Nachricht ────────────────────────────
  if (message) {
    console.log('');
    const msgFn = msgType === 'good' ? C.good : msgType === 'bad' ? C.bad : C.info;
    console.log(msgFn('  » ' + message));
  }

  // ── Hilfe ────────────────────────────────
  console.log('');
  console.log(C.dim('  ─── Befehle ─────────────────────────────'));
  if (selected) {
    console.log(C.dim('  <Ziel>     – z.B. ') + C.prompt('e4') + C.dim('  (Zug ausführen)'));
    console.log(C.dim('  <Figur>    – z.B. ') + C.prompt('d1') + C.dim('  (andere wählen)'));
    console.log(C.dim('  ') + C.prompt('esc') + C.dim(' / ') + C.prompt('x') + C.dim('    – Auswahl aufheben'));
  } else if (isWhite) {
    console.log(C.dim('  <Feld>     – z.B. ') + C.prompt('e2') + C.dim('  (Figur wählen)'));
    console.log(C.dim('  <von-nach> – z.B. ') + C.prompt('e2e4') + C.dim(' (direkt ziehen)'));
  }
  console.log(C.dim('  ') + C.prompt('u') + C.dim('         – Rückgängig'));
  console.log(C.dim('  ') + C.prompt('f') + C.dim('         – Brett drehen'));
  console.log(C.dim('  ') + C.prompt('ai1-5') + C.dim('    – KI-Stärke ändern'));
  console.log(C.dim('  ') + C.prompt('neu') + C.dim('       – Neue Partie'));
  console.log(C.dim('  ') + C.prompt('quit') + C.dim('      – Beenden'));
  console.log('');
}

// ── Zug ausführen ─────────────────────────────
function executeMove(fromR, fromF, toR, toF, extra, promoType = 'Q') {
  const piece = S.board[fromR][fromF];
  const captured = S.board[toR][toF];
  const wasCheck = isInCheck(S, S.turn === 'w' ? 'b' : 'w');
  const isPromo = piece?.[1] === 'P' && (toR === 0 || toR === 7);

  // SAN vor dem Zug
  const san = moveToSAN(S, fromR, fromF, toR, toF, extra, isPromo ? promoType : '');

  S = applyMove(S, fromR, fromF, toR, toF, extra, promoType);
  lastFrom = { r: fromR, f: fromF };
  lastTo   = { r: toR,   f: toF };
  selected = null; selectedMoves = [];

  if (captured)
    (S.turn === 'w' ? capturedB : capturedW).push(captured);

  // Check/Checkmate annotation
  const prevTurn = S.turn;
  let sanAnnot = san;
  if (isInCheck(S, S.turn)) sanAnnot += '+';
  if (!hasAnyLegal(S, S.turn)) sanAnnot = san.replace('+', '') + '#';
  moveHistory.push(sanAnnot);

  return sanAnnot;
}

// ── KI-Zug ───────────────────────────────────
async function doAIMove() {
  draw('KI denkt…', 'info');
  await new Promise(r => setTimeout(r, 120));

  const mv = findBestMove(S, aiLevel, aiLevel <= 2 ? 40 : 15);
  if (!mv) {
    gameOver('w');
    return false;
  }

  const san = executeMove(mv.fromR, mv.fromF, mv.toR, mv.toF, mv.extra);

  if (!hasAnyLegal(S, S.turn)) {
    const inCheck = isInCheck(S, S.turn);
    draw(inCheck ? '♚ Schachmatt! Du hast gewonnen!' : 'Patt! Unentschieden.', 'good');
    await endGame(inCheck ? 'w' : 'draw');
    return false;
  }
  return san;
}

// ── Spielende ────────────────────────────────
async function endGame(winner) {
  gameActive = false;
  clearScreen();
  console.log('');
  console.log(renderBoard(S, { lastFrom, lastTo }, { flipped }));
  console.log('');

  if (winner === 'w') {
    console.log(C.win('  ╔═══════════════════════════════╗'));
    console.log(C.win('  ║     ♔  SCHACHMATT – SIEG!  ♔  ║'));
    console.log(C.win('  ╚═══════════════════════════════╝'));
  } else if (winner === 'b') {
    console.log(C.loss('  ╔═══════════════════════════════╗'));
    console.log(C.loss('  ║    ♛  SCHACHMATT – NIEDER.  ♛ ║'));
    console.log(C.loss('  ╚═══════════════════════════════╝'));
  } else {
    console.log(C.draw('  ╔═══════════════════════════════╗'));
    console.log(C.draw('  ║        ½ UNENTSCHIEDEN  ½      ║'));
    console.log(C.draw('  ╚═══════════════════════════════╝'));
  }

  console.log('');
  console.log(C.info(`  Vollzüge gespielt: ${S.fullmove}`));
  console.log(C.info(`  Zugfolge (${moveHistory.length} Halbzüge):`));
  const chunks = [];
  for (let i = 0; i < moveHistory.length; i += 2)
    chunks.push(`${Math.floor(i/2)+1}. ${moveHistory[i]}${moveHistory[i+1] ? ' ' + moveHistory[i+1] : ''}`);
  console.log(C.move('  ' + chunks.join('  ')));
  console.log('');

  const ans = await ask(C.prompt('  Neue Partie? (j/n): '));
  if (ans.trim().toLowerCase().startsWith('j')) {
    startNewGame();
    await gameLoop();
  } else {
    console.log(C.dim('\n  Auf Wiedersehen!\n'));
    rl.close();
    process.exit(0);
  }
}

// ── Bauernumwandlung ─────────────────────────
async function askPromotion() {
  draw('', 'info');
  console.log(C.title('  ┌─────────────────────────────┐'));
  console.log(C.title('  │   BAUERNUMWANDLUNG           │'));
  console.log(C.title('  │                              │'));
  console.log(C.title('  │  D = Dame   ♕               │'));
  console.log(C.title('  │  T = Turm   ♖               │'));
  console.log(C.title('  │  L = Läufer ♗               │'));
  console.log(C.title('  │  S = Springer ♘             │'));
  console.log(C.title('  └─────────────────────────────┘'));
  console.log('');

  while (true) {
    const ans = (await ask(C.prompt('  Figur wählen (D/T/L/S): '))).trim().toUpperCase();
    const map = { D: 'Q', T: 'R', L: 'B', S: 'N', Q: 'Q', R: 'R', B: 'B', N: 'N' };
    if (map[ans]) return map[ans];
    console.log(C.bad('  Ungültig. D, T, L oder S eingeben.'));
  }
}

// ── Haupt-Spielschleife ───────────────────────
async function gameLoop() {
  gameActive = true;
  let message = '';
  let msgType = 'info';

  while (gameActive) {
    draw(message, msgType);
    message = '';

    const isWhite = S.turn === 'w';

    if (!isWhite) {
      // KI-Zug
      const san = await doAIMove();
      if (san === false) return;
      message = `KI zog: ${san}`;
      msgType = 'info';

      if (!hasAnyLegal(S, S.turn)) {
        const inCheck = isInCheck(S, S.turn);
        await endGame(inCheck ? 'b' : 'draw');
        return;
      }
      continue;
    }

    // Spieler-Eingabe
    const inp = (await ask(C.prompt('  Eingabe: '))).trim().toLowerCase();

    // ── Befehle ──────────────────────────────
    if (inp === 'quit' || inp === 'exit' || inp === 'q') {
      console.log(C.dim('\n  Auf Wiedersehen!\n'));
      rl.close(); process.exit(0);
    }
    if (inp === 'neu' || inp === 'new' || inp === 'n') {
      startNewGame(); continue;
    }
    if (inp === 'f' || inp === 'flip') {
      flipped = !flipped;
      message = 'Brett gedreht.'; msgType = 'info';
      continue;
    }
    if (inp === 'esc' || inp === 'x' || inp === 'abbruch') {
      selected = null; selectedMoves = [];
      message = 'Auswahl aufgehoben.'; msgType = 'info';
      continue;
    }
    if (inp === 'u' || inp === 'undo') {
      if (S.history.length >= 2) {
        // Rückgängig für Spieler + KI-Zug
        const snap2 = S.history[S.history.length - 2];
        S = { ...snap2, board: snap2.board, history: S.history.slice(0, -2) };
        lastFrom = null; lastTo = null; selected = null; selectedMoves = [];
        if (moveHistory.length >= 2) moveHistory.splice(-2, 2);
        else if (moveHistory.length >= 1) moveHistory.pop();
        capturedW = capturedW.slice(0, -1);
        capturedB = capturedB.slice(0, -1);
        message = 'Zug rückgängig gemacht.'; msgType = 'good';
      } else {
        message = 'Kein Zug zum Rückgängigmachen.'; msgType = 'bad';
      }
      continue;
    }
    if (inp.startsWith('ai') || inp.startsWith('ki')) {
      const lvl = parseInt(inp.slice(2));
      if (lvl >= 1 && lvl <= 5) {
        aiLevel = lvl;
        message = `KI-Stärke auf Stufe ${lvl} gesetzt.`; msgType = 'good';
      } else {
        message = 'KI-Stufe: 1–5 eingeben (z.B. "ai3").'; msgType = 'bad';
      }
      continue;
    }

    // ── Zug-Eingabe ──────────────────────────

    // Format: e2e4 oder e2-e4 (direkt)
    const direct = inp.match(/^([a-h][1-8])[-\s]?([a-h][1-8])([qrbn]?)$/);
    if (direct) {
      const from = parseAlg(direct[1]);
      const to   = parseAlg(direct[2]);
      const promoChar = direct[3];
      if (!from || !to) { message = 'Ungültiges Feld.'; msgType = 'bad'; continue; }

      const piece = S.board[from.r][from.f];
      if (!piece || piece[0] !== 'w') {
        message = 'Auf diesem Feld steht keine eigene Figur.'; msgType = 'bad'; continue;
      }

      const legalMoves = getLegalMoves(S, from.r, from.f);
      const mv = legalMoves.find(m => m.r === to.r && m.f === to.f);
      if (!mv) {
        message = `${direct[1]}–${direct[2]} ist kein legaler Zug.`; msgType = 'bad'; continue;
      }

      // Bauernumwandlung?
      let promo = 'Q';
      if (piece[1] === 'P' && (to.r === 0 || to.r === 7)) {
        if (promoChar) {
          const map = { q:'Q', r:'R', b:'B', n:'N' };
          promo = map[promoChar] || 'Q';
        } else {
          draw('', 'info');
          promo = await askPromotion();
        }
      }

      const san = executeMove(from.r, from.f, to.r, to.f, mv, promo);
      message = `Du zogst: ${san}`;

      // Sofort prüfen ob Schachmatt
      if (!hasAnyLegal(S, S.turn)) {
        const inCheck = isInCheck(S, S.turn);
        await endGame(inCheck ? 'w' : 'draw');
        return;
      }
      msgType = 'good';
      selected = null; selectedMoves = [];
      continue;
    }

    // Format: e2 – Figur wählen oder Zug ausführen wenn schon gewählt
    const sq = inp.match(/^([a-h][1-8])$/);
    if (sq) {
      const pos = parseAlg(sq[1]);
      if (!pos) { message = 'Ungültiges Feld.'; msgType = 'bad'; continue; }

      // Wenn Figur schon gewählt: Zug ausführen
      if (selected) {
        const mv = selectedMoves.find(m => m.r === pos.r && m.f === pos.f);
        if (mv) {
          const piece = S.board[selected.r][selected.f];
          let promo = 'Q';
          if (piece[1] === 'P' && (pos.r === 0 || pos.r === 7)) {
            draw('', 'info');
            promo = await askPromotion();
          }
          const san = executeMove(selected.r, selected.f, pos.r, pos.f, mv, promo);
          message = `Du zogst: ${san}`;

          if (!hasAnyLegal(S, S.turn)) {
            const inCheck = isInCheck(S, S.turn);
            await endGame(inCheck ? 'w' : 'draw');
            return;
          }
          msgType = 'good';
          selected = null; selectedMoves = [];
          continue;
        }
      }

      // Neue Figur wählen
      const piece = S.board[pos.r][pos.f];
      if (piece && piece[0] === 'w') {
        const moves = getLegalMoves(S, pos.r, pos.f);
        selected = { r: pos.r, f: pos.f };
        selectedMoves = moves;
        if (!moves.length) {
          message = `${sq[1]} – keine legalen Züge.`; msgType = 'bad';
        } else {
          message = `${sq[1]} gewählt — ${moves.length} Züge möglich.`; msgType = 'info';
        }
      } else if (piece && piece[0] === 'b') {
        message = 'Das ist eine gegnerische Figur.'; msgType = 'bad';
        selected = null; selectedMoves = [];
      } else {
        message = 'Leeres Feld.'; msgType = 'bad';
        selected = null; selectedMoves = [];
      }
      continue;
    }

    // Rochade shorthand
    if (inp === 'o-o' || inp === '00' || inp === 'ks') {
      // Königsseite
      const lm = getLegalMoves(S, 7, 4);
      const castle = lm.find(m => m.castle === 'K');
      if (castle) {
        executeMove(7, 4, 7, 6, castle);
        message = 'Rochade (kurz) ausgeführt.'; msgType = 'good';
        if (!hasAnyLegal(S, S.turn)) { await endGame(isInCheck(S, S.turn) ? 'w' : 'draw'); return; }
      } else { message = 'Kurze Rochade nicht möglich.'; msgType = 'bad'; }
      continue;
    }
    if (inp === 'o-o-o' || inp === '000' || inp === 'ds') {
      const lm = getLegalMoves(S, 7, 4);
      const castle = lm.find(m => m.castle === 'Q');
      if (castle) {
        executeMove(7, 4, 7, 2, castle);
        message = 'Rochade (lang) ausgeführt.'; msgType = 'good';
        if (!hasAnyLegal(S, S.turn)) { await endGame(isInCheck(S, S.turn) ? 'w' : 'draw'); return; }
      } else { message = 'Lange Rochade nicht möglich.'; msgType = 'bad'; }
      continue;
    }

    // Unbekannte Eingabe
    if (inp.length > 0) {
      message = `Unbekannte Eingabe: "${inp}" — Hilfe: Felder eingeben (z.B. e2 oder e2e4)`; msgType = 'bad';
    }
  }
}

// ── Neue Partie ───────────────────────────────
function startNewGame() {
  S           = makeState();
  gameActive  = true;
  moveHistory = [];
  capturedW   = [];
  capturedB   = [];
  lastFrom    = null;
  lastTo      = null;
  selected    = null;
  selectedMoves = [];
}

// ── Hauptmenü ─────────────────────────────────
async function mainMenu() {
  clearScreen();
  console.log('');
  console.log(C.title('  ╔══════════════════════════════════╗'));
  console.log(C.title('  ║                                  ║'));
  console.log(C.title('  ║    ♔    S C H A C H    ♛         ║'));
  console.log(C.title('  ║    Das Spiel der Könige           ║'));
  console.log(C.title('  ║                                  ║'));
  console.log(C.title('  ╚══════════════════════════════════╝'));
  console.log('');
  console.log(C.info('  Du spielst Weiß gegen die KI (Schwarz).'));
  console.log('');
  console.log(C.dim('  ─── KI-Stärke ──────────────────────'));
  console.log(C.dim('  1 – Anfänger    (sehr leicht)'));
  console.log(C.dim('  2 – Lernender   (leicht)'));
  console.log(C.dim('  3 – Amateur     (mittel)  ← Standard'));
  console.log(C.dim('  4 – Fortgeschr. (schwer)'));
  console.log(C.dim('  5 – Experte     (sehr schwer, langsam)'));
  console.log('');
  console.log(C.dim('  ─── Steuerung ───────────────────────'));
  console.log(C.dim('  e2      – Figur auf e2 wählen'));
  console.log(C.dim('  e2e4    – direkt von e2 nach e4 ziehen'));
  console.log(C.dim('  u       – Letzten Zug rückgängig'));
  console.log(C.dim('  f       – Brett umdrehen'));
  console.log(C.dim('  ai3     – KI-Stärke auf 3 setzen'));
  console.log(C.dim('  quit    – Beenden'));
  console.log('');

  const lvlInput = await ask(C.prompt('  KI-Stärke (1-5, Enter=3): '));
  const lvl = parseInt(lvlInput.trim()) || 3;
  aiLevel = Math.max(1, Math.min(5, lvl));

  console.log('');
  console.log(C.good(`  ✓ KI-Stufe ${aiLevel} gewählt. Starte Spiel…`));
  await new Promise(r => setTimeout(r, 600));

  startNewGame();
  await gameLoop();
}

// ── Start ─────────────────────────────────────
process.on('SIGINT', () => {
  console.log(C.dim('\n\n  Spiel beendet.\n'));
  rl.close();
  process.exit(0);
});

mainMenu().catch(err => {
  console.error('Fehler:', err);
  rl.close();
  process.exit(1);
});
