'use strict';

// ════════════════════════════════════════════════
// SCHACH ENGINE – vollständige Regelimplementierung
// Rochade · En passant · Bauernumwandlung · Schach
// Alpha-Beta KI mit Piece-Square-Tables
// ════════════════════════════════════════════════

// Figurwerte
const PV = { P: 100, N: 320, B: 330, R: 500, Q: 900, K: 20000 };

// Piece-Square-Tables (Weiß-Perspektive)
const PST = {
  P: [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [ 50, 50, 50, 50, 50, 50, 50, 50],
    [ 10, 10, 20, 30, 30, 20, 10, 10],
    [  5,  5, 10, 25, 25, 10,  5,  5],
    [  0,  0,  0, 20, 20,  0,  0,  0],
    [  5, -5,-10,  0,  0,-10, -5,  5],
    [  5, 10, 10,-20,-20, 10, 10,  5],
    [  0,  0,  0,  0,  0,  0,  0,  0],
  ],
  N: [
    [-50,-40,-30,-30,-30,-30,-40,-50],
    [-40,-20,  0,  0,  0,  0,-20,-40],
    [-30,  0, 10, 15, 15, 10,  0,-30],
    [-30,  5, 15, 20, 20, 15,  5,-30],
    [-30,  0, 15, 20, 20, 15,  0,-30],
    [-30,  5, 10, 15, 15, 10,  5,-30],
    [-40,-20,  0,  5,  5,  0,-20,-40],
    [-50,-40,-30,-30,-30,-30,-40,-50],
  ],
  B: [
    [-20,-10,-10,-10,-10,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5, 10, 10,  5,  0,-10],
    [-10,  5,  5, 10, 10,  5,  5,-10],
    [-10,  0, 10, 10, 10, 10,  0,-10],
    [-10, 10, 10, 10, 10, 10, 10,-10],
    [-10,  5,  0,  0,  0,  0,  5,-10],
    [-20,-10,-10,-10,-10,-10,-10,-20],
  ],
  R: [
    [  0,  0,  0,  0,  0,  0,  0,  0],
    [  5, 10, 10, 10, 10, 10, 10,  5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [ -5,  0,  0,  0,  0,  0,  0, -5],
    [  0,  0,  0,  5,  5,  0,  0,  0],
  ],
  Q: [
    [-20,-10,-10, -5, -5,-10,-10,-20],
    [-10,  0,  0,  0,  0,  0,  0,-10],
    [-10,  0,  5,  5,  5,  5,  0,-10],
    [ -5,  0,  5,  5,  5,  5,  0, -5],
    [  0,  0,  5,  5,  5,  5,  0, -5],
    [-10,  5,  5,  5,  5,  5,  0,-10],
    [-10,  0,  5,  0,  0,  0,  0,-10],
    [-20,-10,-10, -5, -5,-10,-10,-20],
  ],
  K: [
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-30,-40,-40,-50,-50,-40,-40,-30],
    [-20,-30,-30,-40,-40,-30,-30,-20],
    [-10,-20,-20,-20,-20,-20,-20,-10],
    [ 20, 20,  0,  0,  0,  0, 20, 20],
    [ 20, 30, 10,  0,  0, 10, 30, 20],
  ],
};

function makeBoard() {
  const b = Array.from({ length: 8 }, () => Array(8).fill(null));
  const back = ['R','N','B','Q','K','B','N','R'];
  for (let f = 0; f < 8; f++) {
    b[0][f] = 'b' + back[f];
    b[1][f] = 'bP';
    b[6][f] = 'wP';
    b[7][f] = 'w' + back[f];
  }
  return b;
}

function cloneBoard(b) { return b.map(r => r.slice()); }
function inBounds(r, f) { return r >= 0 && r < 8 && f >= 0 && f < 8; }

function findKing(board, col) {
  for (let r = 0; r < 8; r++)
    for (let f = 0; f < 8; f++)
      if (board[r][f] === col + 'K') return { r, f };
  return null;
}

function makeState() {
  return {
    board: makeBoard(),
    turn: 'w',
    rights: { wK: true, wQ: true, bK: true, bQ: true },
    epSq: null,
    halfmove: 0,
    fullmove: 1,
    history: [],
  };
}

function pseudoMoves(S, r, f) {
  const { board, rights, epSq } = S;
  const p = board[r][f];
  if (!p) return [];
  const col = p[0], type = p[1], opp = col === 'w' ? 'b' : 'w';
  const moves = [];

  const slide = (dr, df) => {
    let nr = r + dr, nf = f + df;
    while (inBounds(nr, nf)) {
      if (!board[nr][nf]) moves.push({ r: nr, f: nf });
      else { if (board[nr][nf][0] === opp) moves.push({ r: nr, f: nf }); break; }
      nr += dr; nf += df;
    }
  };
  const step = (dr, df) => {
    const nr = r + dr, nf = f + df;
    if (inBounds(nr, nf) && (!board[nr][nf] || board[nr][nf][0] === opp))
      moves.push({ r: nr, f: nf });
  };

  if (type === 'P') {
    const dir = col === 'w' ? -1 : 1, startR = col === 'w' ? 6 : 1;
    if (inBounds(r + dir, f) && !board[r + dir][f]) {
      moves.push({ r: r + dir, f });
      if (r === startR && !board[r + 2 * dir][f])
        moves.push({ r: r + 2 * dir, f, doublePush: true });
    }
    for (const df of [-1, 1]) {
      const nr = r + dir, nf = f + df;
      if (!inBounds(nr, nf)) continue;
      if (board[nr][nf] && board[nr][nf][0] === opp) moves.push({ r: nr, f: nf });
      if (epSq && epSq.r === nr && epSq.f === nf) moves.push({ r: nr, f: nf, ep: true });
    }
  } else if (type === 'N') {
    for (const [dr, df] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) step(dr, df);
  } else if (type === 'B') {
    for (const [dr, df] of [[-1,-1],[-1,1],[1,-1],[1,1]]) slide(dr, df);
  } else if (type === 'R') {
    for (const [dr, df] of [[-1,0],[1,0],[0,-1],[0,1]]) slide(dr, df);
  } else if (type === 'Q') {
    for (const [dr, df] of [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]) slide(dr, df);
  } else if (type === 'K') {
    for (const [dr, df] of [[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]]) step(dr, df);
    const hr = col === 'w' ? 7 : 0;
    if (r === hr && f === 4) {
      if (rights[col+'K'] && !board[hr][5] && !board[hr][6] && board[hr][7] === col+'R')
        moves.push({ r: hr, f: 6, castle: 'K' });
      if (rights[col+'Q'] && !board[hr][3] && !board[hr][2] && !board[hr][1] && board[hr][0] === col+'R')
        moves.push({ r: hr, f: 2, castle: 'Q' });
    }
  }
  return moves;
}

function isAttacked(S, r, f, byCol) {
  for (let rr = 0; rr < 8; rr++)
    for (let ff = 0; ff < 8; ff++) {
      if (S.board[rr][ff]?.[0] !== byCol) continue;
      if (pseudoMoves({ ...S, turn: byCol }, rr, ff).some(m => m.r === r && m.f === f)) return true;
    }
  return false;
}

function isInCheck(S, col) {
  const k = findKing(S.board, col);
  if (!k) return false;
  return isAttacked(S, k.r, k.f, col === 'w' ? 'b' : 'w');
}

function applyMove(S, fromR, fromF, toR, toF, extra = {}, promoType = 'Q') {
  const board = cloneBoard(S.board);
  const p = board[fromR][fromF], col = p[0];
  const captured = board[toR][toF];

  board[fromR][fromF] = null;
  board[toR][toF] = p;

  if (extra.ep && p[1] === 'P') board[col === 'w' ? toR + 1 : toR - 1][toF] = null;
  if (p[1] === 'P' && (toR === 0 || toR === 7)) board[toR][toF] = col + promoType;
  if (extra.castle === 'K') { board[toR][5] = col + 'R'; board[toR][7] = null; }
  if (extra.castle === 'Q') { board[toR][3] = col + 'R'; board[toR][0] = null; }

  const rights = { ...S.rights };
  if (p[1] === 'K') { rights[col+'K'] = false; rights[col+'Q'] = false; }
  if (p[1] === 'R') {
    if (col==='w' && fromR===7 && fromF===7) rights.wK = false;
    if (col==='w' && fromR===7 && fromF===0) rights.wQ = false;
    if (col==='b' && fromR===0 && fromF===7) rights.bK = false;
    if (col==='b' && fromR===0 && fromF===0) rights.bQ = false;
  }
  const epSq = (p[1] === 'P' && extra.doublePush)
    ? { r: col === 'w' ? toR + 1 : toR - 1, f: toF } : null;
  const halfmove = (p[1] === 'P' || captured || extra.ep) ? 0 : S.halfmove + 1;
  const nextTurn = S.turn === 'w' ? 'b' : 'w';

  const snap = { board: cloneBoard(S.board), rights: { ...S.rights }, epSq: S.epSq, turn: S.turn, halfmove: S.halfmove };

  return {
    board, rights, epSq, turn: nextTurn,
    halfmove, fullmove: S.fullmove + (nextTurn === 'w' ? 1 : 0),
    history: [...S.history, snap],
    lastMove: { fromR, fromF, toR, toF, piece: p, captured },
  };
}

function getLegalMoves(S, r, f) {
  const p = S.board[r][f]; if (!p) return [];
  const col = p[0], opp = col === 'w' ? 'b' : 'w';
  return pseudoMoves(S, r, f).filter(m => {
    if (m.castle) {
      if (isInCheck(S, col)) return false;
      const mf = m.castle === 'K' ? 5 : 3;
      if (isAttacked(S, r, 4, opp)) return false;
      if (isAttacked(S, r, mf, opp)) return false;
      if (isAttacked(S, r, m.f, opp)) return false;
    }
    return !isInCheck(applyMove(S, r, f, m.r, m.f, m), col);
  });
}

function getAllLegalMoves(S, col) {
  const moves = [];
  for (let r = 0; r < 8; r++)
    for (let f = 0; f < 8; f++) {
      if (S.board[r][f]?.[0] !== col) continue;
      for (const m of getLegalMoves(S, r, f))
        moves.push({ fromR: r, fromF: f, toR: m.r, toF: m.f, extra: m });
    }
  return moves;
}

function hasAnyLegal(S, col) { return getAllLegalMoves(S, col).length > 0; }

// ── Algebraische Notation ─────────────────
function toAlg(f) { return String.fromCharCode(97 + f); }
function sqToStr(r, f) { return toAlg(f) + (8 - r); }

function parseAlg(str) {
  if (!str || str.length < 2) return null;
  const s = str.trim().toLowerCase();
  const f = s.charCodeAt(0) - 97;
  const r = 8 - parseInt(s[1], 10);
  if (!inBounds(r, f)) return null;
  return { r, f };
}

function moveToSAN(S, fromR, fromF, toR, toF, extra, promo = '') {
  if (extra?.castle === 'K') return 'O-O';
  if (extra?.castle === 'Q') return 'O-O-O';
  const p = S.board[fromR][fromF];
  const type = p[1];
  const cap = S.board[toR][toF] || extra?.ep;
  const prefix = type === 'P' ? (cap ? toAlg(fromF) : '') : type;
  return prefix + (cap ? 'x' : '') + sqToStr(toR, toF) + (promo ? '=' + promo : '');
}

// ── Evaluation ────────────────────────────
function evaluate(S) {
  let score = 0;
  for (let r = 0; r < 8; r++)
    for (let f = 0; f < 8; f++) {
      const p = S.board[r][f]; if (!p) continue;
      const col = p[0], type = p[1];
      const base = PV[type] || 0;
      const pst = PST[type] ? PST[type][col === 'w' ? r : 7 - r][f] : 0;
      score += (col === 'w' ? 1 : -1) * (base + pst);
    }
  return score;
}

function mvScore(S, mv) {
  const victim = S.board[mv.toR][mv.toF];
  const attacker = S.board[mv.fromR][mv.fromF];
  if (!victim) return mv.extra?.castle ? 50 : 0;
  return ((PV[victim[1]] || 0) * 10) - (PV[attacker?.[1]] || 0);
}

function negamax(S, depth, alpha, beta) {
  if (depth <= 0) {
    const e = evaluate(S);
    return S.turn === 'w' ? e : -e;
  }
  const moves = getAllLegalMoves(S, S.turn);
  if (!moves.length) return isInCheck(S, S.turn) ? -999999 + depth : 0;
  moves.sort((a, b) => mvScore(S, b) - mvScore(S, a));
  let best = -Infinity;
  for (const mv of moves) {
    const ns = applyMove(S, mv.fromR, mv.fromF, mv.toR, mv.toF, mv.extra);
    const score = -negamax(ns, depth - 1, -beta, -alpha);
    if (score > best) best = score;
    if (score > alpha) alpha = score;
    if (alpha >= beta) break;
  }
  return best;
}

function findBestMove(S, depth = 3, randomness = 20) {
  const moves = getAllLegalMoves(S, S.turn);
  if (!moves.length) return null;
  moves.sort((a, b) => mvScore(S, b) - mvScore(S, a));
  let best = null, bestScore = -Infinity;
  for (const mv of moves) {
    const ns = applyMove(S, mv.fromR, mv.fromF, mv.toR, mv.toF, mv.extra);
    let score = -negamax(ns, depth - 1, -Infinity, Infinity);
    score += (Math.random() - 0.5) * randomness;
    if (score > bestScore) { bestScore = score; best = mv; }
  }
  return best;
}

module.exports = {
  makeState, applyMove, getLegalMoves, getAllLegalMoves, hasAnyLegal,
  isInCheck, parseAlg, sqToStr, toAlg, moveToSAN, evaluate, findBestMove,
  PV, inBounds,
};
