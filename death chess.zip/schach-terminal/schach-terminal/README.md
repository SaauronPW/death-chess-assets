# ♔ SCHACH – Terminal Edition

Vollständiges Schachspiel für die Kommandozeile. Node.js, keine GUI nötig.

## Installation

```bash
unzip schach-terminal.zip
cd schach-terminal
npm install
node src/index.js
```

## Steuerung

| Eingabe       | Aktion                                 |
|---------------|----------------------------------------|
| `e2`          | Figur auf e2 auswählen                 |
| `e4`          | Ausgewählte Figur nach e4 bewegen      |
| `e2e4`        | Direkt von e2 nach e4 ziehen           |
| `e7e8q`       | Bauer umwandeln (q=Dame, r=Turm, b=Läufer, n=Springer) |
| `o-o`         | Kurze Rochade                          |
| `o-o-o`       | Lange Rochade                          |
| `u`           | Letzten Zug (+ KI-Zug) rückgängig     |
| `f`           | Brett drehen (Schwarz unten)           |
| `ai1`–`ai5`   | KI-Stärke ändern (1=leicht, 5=stark)  |
| `neu`         | Neue Partie                            |
| `quit`        | Beenden                                |

## Funktionen

- ✅ Vollständige Schachregeln
- ✅ Rochade (kurz + lang)
- ✅ En passant
- ✅ Bauernumwandlung
- ✅ Schacherkennung
- ✅ Schachmatt & Patt
- ✅ Alpha-Beta KI (Tiefe 1–5)
- ✅ Piece-Square-Tables für positionelles Spiel
- ✅ Farbiges Board (chalk)
- ✅ Zugliste in SAN-Notation
- ✅ Zug rückgängig
- ✅ Brett spiegeln

## Systemanforderungen

- Node.js ≥ 14
- Terminal mit Unicode-Unterstützung (für ♔♛ Symbole)
- Bei Windows: Windows Terminal empfohlen
